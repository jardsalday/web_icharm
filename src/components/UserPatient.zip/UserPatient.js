import React, {Component} from 'react';
import axios from 'axios';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {getSpecPatient} from '../actions/assessActions';
import {Link,NavLink} from 'react-router-dom';
import patient from '../reducers/patient';
import '../App.css'
import { PatientComponent } from './PatientComponent';
import { CreatePatient } from './CreatePatient';
import Assess from './Assess';
import Pagination from './Pagination';
import Graph from './Graph';
import RiskGraph from './RiskGraph';
import Description from './Description';
import { CSSTransitionGroup } from 'react-transition-group';
import {Line} from 'react-chartjs-2';

export class UserPatient extends Component{
 
    state = {
        patientOne:[],
        systolic:[],
        all:{},
        risk:{},
        sys:{},
        dia:{},
        weight:{},
        cholesterol:{},
        truesys:{},
        cholesterol2:{},
        displayrisk:"",
        desc:{},
        refresh:false
        
        

    }

  

  componentDidMount(){
    // const patientID = this.props.match.params.patientID; 
    // //this.props.getSpecPatient(patientID);
    // axios.get(`http://192.168.43.164:8000/api/getspecific/?id=${patientID}`).then(res=>{this.setState({patientOne:res.data});console.log(res.data)});
    //         axios.all([axios.get(`http://192.168.43.164:8000/api/specrisk/?id_number=${patientID}`),
    //        axios.get(`http://192.168.43.164:8000/api/specmeasure/?id_number=${patientID}`)])
    //  .then(axios.spread((firstResponse, secondResponse) => {  
    //      const risk = firstResponse.data
    //      const measure  =secondResponse.data
    //      const measure2 = secondResponse.data
    //      console.log(risk[risk.length-1].risk_proba)
    //     //  const measure2 = secondResponse.data;
    //      console.log(measure);
    //      console.log(risk)
    //     // const measure = measure2.map(function(test1){return{systolic:test1.systolic,diastolic:test1.diastolic,weight:test1.weight,
    //         // cholesterol:test1.cholesterol}});
        
    //      this.setState({
    //        displayrisk:risk[risk.length-1].risk_proba,
    //        desc:measure[measure.length-1],
    //       risk:{
    //         labels:risk.map(test=>test.created_at),
    //     datasets:[
    //             {
    //                 label:"CVD Risk",
    //                 borderColor: "rgb(229, 115, 115)",
    //                 fill:true,
    //                 lineTension:0,
    //                 backgroundColor:"rgba(229, 115, 115,0.2)",
    //               data:risk.map(test=>test.risk_proba)
    //             }]

    //             },
                  
    //             sys:{
    //                 labels:measure.map(test=>test.created_at),
    //             datasets:[
    //                     {
    //                         label:"Systolic Pressure",
    //                         borderColor: "#66bb6a",
    //                         lineTension:0.5,
    //                         data:measure.map(test=>test.systolic)
    //                     }]
        
    //           },
    //           dia:{
    //             labels:measure.map(test=>test.created_at),
    //         datasets:[
    //                 {
    //                     label:"Diastolic Pressure",
    //                     borderColor: "#2196f3",
    //                     fill:true,
    //                     lineTension:0.5,
    //                     backgroundColor:"rgba(124, 179, 66,0.2)",
    //                     data:measure.map(test=>test.diastolic)
    //                 }]
        
    //       },
    //       weight:{
    //         labels:measure.map(test=>test.created_at),
    //     datasets:[
    //             {
    //                 label:"Weight",
    //                 borderColor: "#ffb74d",
    //                 fill:true,
    //                 lineTension:0.5,            
    //                 backgroundColor:"rgba(255, 183, 77,0.2)",
    //                 data:measure.map(test=>test.weight)
    //             }]
        
    //     },
        
    //     cholesterol:{
    //         labels:measure.map(test=>test.created_at),
    //     datasets:[
    //             {
    //                 label:"Cholesterol Level",
    //                 borderColor: "#ffee58",
    //                 fill:false,
    //                 lineTension:0.5,
    //                 backgroundColor:"rgba(200, 200, 0,0.2)",
    //                 data:measure.map(test=>test.cholesterol)
    //             },
    //             {
    //               label:"Systolic Pressure",
    //               borderColor: "rgba(0, 200, 0)",  
    //               lineTension:0.4,
    //               fill:false,
    //               data:measure2.map(test=>test.systolic)
    //           },
    //           {
    //             label:"Diastolic Pressure",
    //             borderColor: "#2196f3",
    //             fill:false,
    //             lineTension:0.3,
    //             backgroundColor:"rgba(124, 179, 66,0.2)",
    //             data:measure.map(test=>test.diastolic)
    //         },
    //         {
    //           label:"Weight",
    //           borderColor: "#ffb74d",
    //           fill:false,
    //           lineTension:0.2,            
    //           backgroundColor:"rgba(255, 183, 77,0.2)",
    //           data:measure.map(test=>test.weight)
    //       }
    //           ]
        
    //     },
    //     cholesterol2:{
    //       labels:measure.map(test=>test.created_at),
    //   datasets:[
    //           {
    //               label:"Cholesterol Level",
    //               borderColor: "#ffee58",
    //               fill:true,
    //               lineTension:0.5,
    //               backgroundColor:"rgba(200, 200, 0,0.2)",
    //               data:measure.map(test=>test.cholesterol)
    //           }
    //         ]
      
    //   }
    
    // });
    //  }))
    //  .catch(error => console.log(error));
        
    //     axios.get('http://192.168.43.164:8000/api/risk/').then(res=>{ const array = res.data;this.setState({risk:{
    //         labels:array.map(test=>test.created_at),
    //     datasets:[
    //             {
    //                 label:"CVD Risk",
    //                 borderColor: "rgb(229, 115, 115)",
    //                 fill:true,
    //                 lineTension:0.5,
    //                 backgroundColor:"rgba(229, 115, 115,0.2)",
    //               data:array.map(test=>test.risk_proba)
    //             }]

    //   }
    
    
    // // });});
  }
  
    render(){
      
      

        return (
            <div className="background  grey lighten-3">
            
            

             <div class="navbar-fixed">
             <nav class="nav-wrapper red lighten-2">
                             <div class="container">
                                 <a href="#" class="brand-logo">iCHARM</a>
                                 <a href="#" class="sidenav-trigger" data-target="mobile-links">
                                 <i class="material-icons">menu</i>
                                 </a>
                                 <ul class="right hide-on-med-and-down">
                                 <li><NavLink to ="/patient" className="btn white red-text text-lighten-2" ><span className="glyphicon glyphicon-align-left"></span>Home</NavLink></li>
             			<li> <Link to ="/admin"><span className="	glyphicon glyphicon-user"></span>Measures</Link></li>
                   <li> <Link to ="/admin"><span className="	glyphicon glyphicon-user"></span>Trends</Link></li>
                   <li> <Link to ="/admin"><span className="	glyphicon glyphicon-user"></span>Profile</Link></li>
                                 <li><a href="/login" class="white-text"><span className="glyphicon glyphicon-log-out"></span>Logout</a></li>
                                 </ul>
                             </div>
                             </nav>
                         </div>
                        <ul class="sidenav" id="mobile-links">
                          <li><Link to ="/patient"></Link></li>
            			<li> <Link to ="/admin">Admin</Link></li>

                                 <li><a href="/" class="btn white red-text text-lighten-2">Logout</a></li>
                         </ul> 
                         <div className="row">
                                  
                         <div className="col-lg-6 guide card-panel white">
                         <div><i className=" nav-gear	glyphicon glyphicon-cog red-text text-lighten-2"></i>{'   '  }<h4 className="grey-text text-darken-1">Navigation</h4>
                           </div><ul className="grey-text text-darken-1">
                           <li><i className="	glyphicon glyphicon-home red-text text-lighten-2"></i>Home:Lorem ipsum dolor sit amet, consectetur adipiscing </li>
                           <li><i className="glyphicon glyphicon-list-alt red-text text-lighten-2"></i>Measures:Lorem ipsum dolor sit amet, consectetur adipiscing </li>
                           <li><i className="glyphicon glyphicon-signal red-text text-lighten-2"></i>Trends:Lorem ipsum dolor sit amet, consectetur adipiscing </li>
                           <li><i className="glyphicon glyphicon-user red-text text-lighten-2"></i>Profile:Lorem ipsum dolor sit amet, consectetur adipiscing </li>
                           </ul>
                           </div>
                         <div className="contact  col-lg-4 card-panel white">
                        <i className="con-icon red-text text-lighten-2	glyphicon glyphicon-envelope"></i>
                        <h4 className="grey-text text-darken-1">Medical Contacts</h4>
                        <ul>

                          <li>
                          <i className="red-text text-lighten-2		fa fa-user-md"></i>
                          <span className="grey-text text-darken-1">Doctor: </span><span className="green-text">James Reid</span>
                          </li>
                          <li>
                          <i className="red-text text-lighten-2			fas fa-compass  "></i>
                          <span className="grey-text text-darken-1">Hospital:</span><span className="green-text"> Saint Malik</span>
                          </li>
                          <li>
                          <i className="red-text text-lighten-2			fas fa-phone  "></i>
                          <span className="grey-text text-darken-1">Contact Number:</span><span className="green-text">#87000</span>
                          </li>
                        </ul>
                
                        </div>
                      
                        <div className="row">
                         <div className = "trends col-lg-6 card-panel white"><h4>Trends</h4></div>
                         <div className= "measures col-lg-4 card-panel red">Measure</div>
                         </div>
                         </div>
                
      </div>
        );


    }




}


export default UserPatient;
/**
  */