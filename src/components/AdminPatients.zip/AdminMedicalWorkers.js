import React, {Component} from 'react';
import axios from 'axios';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {searchMedic} from '../actions/patientActions';
import AdminCreateMedic from './AdminCreateMedic';
import {Link,NavLink} from 'react-router-dom';
import {Button,ButtonToolbar} from 'react-bootstrap';
import AdminModal from './AdminModal';

//const TransitionGroup = React.addons.TransitionGroup;
export class AdminMedicalWorkers extends Component{
    state={
        admin_medics:[],
        search:'',
        currentPage: 1,
      todosPerPage: 3,
      bgColor:'green',
      activeIndex:1,
      show:false
    
      }
      static propTypes={
        medics:PropTypes.array.isRequired,
        searchMedic:PropTypes.func.isRequired
      }
    componentDidMount(){
        //axios.get('http://172.20.10.11:8000/api/getmedic/').then(res=>{this.setState({admin_medics:res.data})})
      }
      searchName=e=>{
        e.preventDefault();
        const {search} = this.state
        if(search.length==0){
            console.log("YEAH")
        }
        else{
          this.props.searchMedic(search);
           // axios.get(`http://127.0.0.1:8000/api/getmedic/?name=${search}`).then(res=>{this.setState({admin_medics:res.data});console.log(res.data)});
            // this.props.searchPatient(search);
        }
        }
    clearName=e=>{
        e.preventDefault();
        this.props.searchMedic("12345")
        //axios.get('http://127.0.0.1:8000/api/getmedic/?name=12345').then(res=>{this.setState({admin_medics:res.data})});
          
    }
    handleClick(event) {
      this.setState({
        currentPage: Number(event.target.id) ,
        activeIndex: event.target.id
      });
  }
  showHide(){
    this.setState({show:!this.state.show});
  }
    onChange=e=> this.setState({[e.target.name]:e.target.value}) 
    render(){
      const { todos, currentPage, todosPerPage } = this.state;
        const indexOfLastTodo = currentPage * todosPerPage;
        const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
        const currentTodos = this.props.medics.slice(indexOfFirstTodo, indexOfLastTodo);
        console.log(currentTodos);
        const pageNumbers = [];
        for (let i = 1; i <= Math.ceil(this.props.medics.length / todosPerPage); i++) {
          pageNumbers.push(i);
        }
        const renderPageNumbers = pageNumbers.map(number => {
            return (
              <li
                key={number}
                id={number}
                onClick={this.handleClick.bind(this)}
                className={number==this.state.activeIndex?"btn green white-text":null}
              >
                {number}
              </li>
            );
          });
      const {search} = this.state
       let addModalClose = ()=> this.setState({addModalShow:false});
        return (
            <div className=" background grey lighten-3">
                <div class="navbar-fixed">
                            <nav class="nav-wrapper red lighten-2">
                            <div class="container">
                                <a href="#" class="brand-logo">iCHARM (Admin)</a>
                                <a href="#" class="sidenav-trigger" data-target="mobile-links">
                                <i class="material-icons">menu</i>
                                </a>
                                <ul class="right hide-on-med-and-down">
                                <li><NavLink to ="/adminprofile"  ><span className="glyphicon glyphicon-home"></span>Home</NavLink></li>
             			<li> <Link to ="/adminpatients" ><span className="glyphicon glyphicon-th-list"></span>Patients Records</Link></li>
                   <li> <Link to ="/adminmedics" className="btn white red-text text-lighten-2" ><span className="glyphicon glyphicon-globe"></span>Medics Records</Link></li>
                   <li><NavLink to ="/adminprofile"  ><span className="glyphicon glyphicon-user"></span> Profile</NavLink></li>
<li><a href="/login" class="white-text"><span className="glyphicon glyphicon-log-out"></span> Logout</a></li>
                                </ul>
                            </div>
                            </nav>
                        </div>

                        <ul class="sidenav" id="mobile-links">
                            <li><Link to ="/adminpatients">Patient Records</Link></li>
            			<li> <Link to ="/adminmedics">Medical Workers</Link></li>
                                <li><a href="/login" class="btn white red-text"> Logout</a></li>
                        </ul>
                <br></br>
                         
                         
                

                <div className="row">
                <button className="btn green white-text add-medic" onClick={this.showHide.bind(this)}>{this.state.show?<span>HIDE FORM</span>:<span>ADD MEDIC</span>}</button>
                <div className={this.state.show?"col s12 background2":"col display s12 background2"}>
                  <AdminCreateMedic showHide={this.showHide.bind(this)}/>
                  </div>
                <div className="col s12  background3">
                <div className="col-lg-6"><h6 className="header-form-text"><span className="glyphicon glyphicon-list"></span>MEDICS List</h6>
                </div>
                <div className="col-lg-3"><input className="searchbox" type="text" onChange={this.onChange} name="search" value={search}/> </div>
                <div className="col-lg-1"><button className="searchbtn btn blue" onClick={this.searchName.bind(this)}><span className="glyphicon glyphicon-search"></span></button>
                
                   </div>
                   <div className="col-lg-1 "><button onClick={this.clearName.bind(this)} className="clearbtn btn grey white-text">CLEAR</button></div>   
                    
               
               
               
                
                <table className="table table-striped table-hover table-condensed" ref={el =>this.el = el} >
                        <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Age</th>
              <th>Sex</th>
              <th>Address</th>
              <th>Hospital</th>
              <th>Role</th>
              <th>Action</th>
            
            </tr></thead>
            <tbody id="myTable">
            {       
                   
                   // console.log(array)
                    currentTodos.sort((a, b) => (-1* (a.name-b.name))).map(patient =>(
                       <tr key={patient.user_id}>
                        <td>{patient.user_id}</td>
                        <td>{patient.name}</td>
                        <td>{patient.birthdate}</td>
                         <td>{patient.sex}</td>
                         <td>{patient.address}</td>
                        <td>{patient.hospital }</td>
                        <td>{patient.position}</td>                            
                          <td><button className="btn btn-small green lighten-1 white-text">
                              {'  '}
                                  <Link to={`/admineditmedic/${patient.user_id}`}><span className="	glyphicon glyphicon-folder-open">
                                  </span></Link>
                              </button>
                              {'  '}
                          </td>  
                         </tr>

                     )
                    


                     )

                }
            
            </tbody>
          </table>
          <ul id="page-numbers">
             {renderPageNumbers}
         </ul>     
                   
          </div>
          
                
          </div>

         
               
            </div>
        );


    }




}
const mapStateToProps = state =>({
 medics:state.medicreducer.medics

});
export default connect(mapStateToProps,{searchMedic})(AdminMedicalWorkers);
